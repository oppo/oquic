/* SPDX-License-Identifier: (BSD-3-Clause OR GPL-2.0-only) */
/* Copyright(c) 2021 Intel Corporation */

#ifndef ADF_C4XXX_ACCEL_UNITS_H_
#define ADF_C4XXX_ACCEL_UNITS_H_

#include <adf_accel_devices.h>

#define ADF_C4XXX_NUM_ACCEL_PER_AU 2
#define ADF_C4XXX_4_AE 4
#ifndef USER_SPACE
enum adf_accel_unit_services {
	ADF_ACCEL_SERVICE_NULL = 0,
	ADF_ACCEL_INLINE_CRYPTO =  1,
	ADF_ACCEL_CRYPTO =  2,
	ADF_ACCEL_COMPRESSION =  4
};

struct adf_ae_info {
	u32 num_asym_thd;
	u32 num_sym_thd;
	u32 num_dc_thd;
};

struct adf_accel_unit {
	u8 au_mask;
	u32 accel_mask;
	u32 ae_mask;
	u32 comp_ae_mask;
	u32 num_ae;
	enum adf_accel_unit_services services;
};

struct adf_accel_unit_info {
	u32 inline_ingress_msk;
	u32 inline_egress_msk;
	u32 sym_ae_msk;
	u32 asym_ae_msk;
	u32 dc_ae_msk;
	u8 num_cy_au;
	u8 num_dc_au;
	u8 num_inline_au;
	struct adf_accel_unit *au;
	const struct adf_ae_info *ae_info;
};
#endif

#define ADF_C4XXX_LEGFUSE_BASE_SKU_MASK (BIT(2) | BIT(3))

/* Return interrupt accelerator source mask */
#define ADF_C4XXX_IRQ_SRC_MASK(accel) (1 << (accel))

/* Slice Hang enabling related registers  */
#define ADF_C4XXX_SHINTMASKSSM (0x1018)
#define ADF_C4XXX_SSMWDTL (0x54)
#define ADF_C4XXX_SSMWDTH (0x5C)
#define ADF_C4XXX_SSMWDTPKEL (0x58)
#define ADF_C4XXX_SSMWDTPKEH (0x60)
#define ADF_C4XXX_SLICEHANGSTATUS (0x4C)
#define ADF_C4XXX_IASLICEHANGSTATUS (0x50)
#define ADF_C4XXX_SHINTMASKSSM_VAL (0x00)
#define ADF_C4XXX_SLICEHANG_ERR_BIT BIT(13)

/* Return address of SHINTMASKSSM register for a given accelerator */
#define ADF_C4XXX_SHINTMASKSSM_OFFSET(accel) \
		(ADF_C4XXX_SHINTMASKSSM + ((accel) * 0x4000))

/* Return address of SLICEHANGSTATUS register for a given accelerator */
#define ADF_C4XXX_SLICEHANGSTATUS_OFFSET(accel) \
		(ADF_C4XXX_SLICEHANGSTATUS + ((accel) * 0x4000))

/* Return address of IASLICEHANGSTATUS register for a given accelerator */
#define ADF_C4XXX_IASLICEHANGSTATUS_OFFSET(accel) \
		(ADF_C4XXX_IASLICEHANGSTATUS + ((accel) * 0x4000))

#define ADF_C4XXX_IAINTSTATSSM(i)	((i) * 0x4000 + 0x206C)
/* Set default value of Slice Hang watchdogs in clock cycles */
#define ADF_C4XXX_SSM_WDT_64BIT_DEFAULT_VALUE 0x3D0900
#define ADF_C4XXX_SSM_WDT_PKE_64BIT_DEFAULT_VALUE 0x3000000

/* Return address of SSMWDTL register for a given accelerator */
#define ADF_C4XXX_SSMWDTL_OFFSET(accel) \
		(ADF_C4XXX_SSMWDTL + ((accel) * 0x4000))

/* Return address of SSMWDTH register for a given accelerator */
#define ADF_C4XXX_SSMWDTH_OFFSET(accel) \
		(ADF_C4XXX_SSMWDTH + ((accel) * 0x4000))

/* Return address of SSMWDTPKEL register for a given accelerator */
#define ADF_C4XXX_SSMWDTPKEL_OFFSET(accel) \
		(ADF_C4XXX_SSMWDTPKEL + ((accel) * 0x4000))

/* Return address of SSMWDTPKEH register for a given accelerator */
#define ADF_C4XXX_SSMWDTPKEH_OFFSET(accel) \
		(ADF_C4XXX_SSMWDTPKEH + ((accel) * 0x4000))

int get_num_accel_units_c4xxx(struct adf_hw_device_data *self);
int adf_init_accel_units_c4xxx(struct adf_accel_dev *accel_dev);
void adf_exit_accel_units_c4xxx(struct adf_accel_dev *accel_dev);
int adf_configure_accel_units_c4xxx(struct adf_accel_dev *accel_dev);
bool adf_check_slice_hang_c4xxx(struct adf_accel_dev *accel_dev);
void adf_enable_slice_hang_detection_c4xxx(struct adf_accel_dev *accel_dev);
int adf_set_ssm_wdtimer_c4xxx(struct adf_accel_dev *accel_dev);
int get_fw_image_type_c4xxx(struct adf_accel_dev *accel_dev,
			    enum adf_cfg_fw_image_type *fw_image_type);
#endif
